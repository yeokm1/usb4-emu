total 0
drwxr-xr-x 2 root root 0 Oct 14 14:40 .
drwxr-xr-x 4 root root 0 Oct 14 14:38 ..
lrwxrwxrwx 1 root root 0 Oct 14 14:38 0-0 -> ../../../devices/pci0000:00/0000:00:0d.2/domain0/0-0
lrwxrwxrwx 1 root root 0 Oct 14 14:38 1-0 -> ../../../devices/pci0000:00/0000:00:0d.3/domain1/1-0
lrwxrwxrwx 1 root root 0 Oct 14 14:38 domain0 -> ../../../devices/pci0000:00/0000:00:0d.2/domain0
lrwxrwxrwx 1 root root 0 Oct 14 14:38 domain1 -> ../../../devices/pci0000:00/0000:00:0d.3/domain1
