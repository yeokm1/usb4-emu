total 0
drwxr-xr-x 2 root root 0 Oct 23 00:01 .
drwxr-xr-x 4 root root 0 Oct 23 00:01 ..
lrwxrwxrwx 1 root root 0 Oct 23 00:02 0-0 -> ../../../devices/pci0000:00/0000:00:1c.4/0000:03:00.0/0000:04:00.0/0000:05:00.0/domain0/0-0
lrwxrwxrwx 1 root root 0 Oct 23 00:02 domain0 -> ../../../devices/pci0000:00/0000:00:1c.4/0000:03:00.0/0000:04:00.0/0000:05:00.0/domain0
