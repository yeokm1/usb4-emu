total 0
drwxr-xr-x 2 root root 0 Oct 14 13:39 .
drwxr-xr-x 4 root root 0 Oct 14 13:38 ..
