total 0
drwxr-xr-x 2 root root 0 Oct 15 12:49 .
drwxr-xr-x 4 root root 0 Oct 15 12:49 ..
