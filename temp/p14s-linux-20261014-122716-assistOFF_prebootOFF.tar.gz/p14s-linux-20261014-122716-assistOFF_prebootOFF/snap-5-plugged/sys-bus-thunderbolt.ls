total 0
drwxr-xr-x 2 root root 0 Oct 14 12:28 .
drwxr-xr-x 4 root root 0 Oct 14 12:27 ..
lrwxrwxrwx 1 root root 0 Oct 14 12:27 0-0 -> ../../../devices/pci0000:00/0000:00:1c.4/0000:03:00.0/0000:04:00.0/0000:05:00.0/domain0/0-0
lrwxrwxrwx 1 root root 0 Oct 14 12:28 0-1 -> ../../../devices/pci0000:00/0000:00:1c.4/0000:03:00.0/0000:04:00.0/0000:05:00.0/domain0/0-0/0-1
lrwxrwxrwx 1 root root 0 Oct 14 12:27 domain0 -> ../../../devices/pci0000:00/0000:00:1c.4/0000:03:00.0/0000:04:00.0/0000:05:00.0/domain0
